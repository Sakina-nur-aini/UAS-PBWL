    
    
    <?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="card">
        <div class="card-body">
            
        <!-- Konten Anda -->
        <script>
            <?php if(session('alert-success')): ?>
                alert('<?php echo e(session('alert-success')); ?>');
            <?php endif; ?>
        </script>


        <strong><h3>Data Pengadilan</h3></strong>
        <a href="<?php echo e(url('pengadilan/create')); ?>" class="btn btn-primary mb-3 float-end"><i class="bi bi-plus"></i> Tambah Baru</a>

        <table id="dataTable" class="table table-hover table-striped table-bordered"><table class="table table-hover table-striped table-bordered">
            <thead>
            <tr>
                <th scope="col" class="text-center">No</th>
                <th scope="col">Nama Pengadilan</th>
                <th scope="col">Alamat</th>
                <th scope="col">Telepon</th>
                <th scope="col">Email</th>
                <th scope="col" class="text-center">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1; ?>
            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengadilan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th class="text-center"><?php echo e($no++); ?></th>
                <td><?php echo e($pengadilan->nama_pengadilan); ?></td>
                <td><?php echo e($pengadilan->alamat); ?></td>
                <td><?php echo e($pengadilan->telepon); ?></td>
                <td><?php echo e($pengadilan->email); ?></td>
                <td class="text-center">
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(url('pengadilan/edit/' . $pengadilan->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(url('pengadilan/' . $pengadilan->id)); ?>" method="post">
                            <input type="hidden" name="_method" value="DELETE">
                            <?php echo csrf_field(); ?>
                            <input type="submit" value="Delete" class="btn btn-danger" onclick="return confirm('Ingin Menghapus Data Ini ?');">
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl\UAS\pbwl-sidang\resources\views/pengadilan/index.blade.php ENDPATH**/ ?>