@extends('layouts.app')

@section('content')
<div class="container"> 
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Form Edit Peserta Sidang</h5>
            <div class="col-sm-8">
                <form class="row g-3 mt-2" action="{{ url('gaji/' . $row->id) }}" method="POST">
                    <input type="hidden" name="_method" value="PATCH">
                    @csrf

                    <div class="mb-3">
                        <label for="id_karyawan" class="form-label">Karyawan*</label>
                        <select class="form-control" name="id_karyawan" id="id_karyawan">
                            <option value="">-- Pilih --</option>
                            @foreach($karyawans as $karyawan)
                                <option value="{{ $karyawan->id }}" {{ $row->id_karyawan == $karyawan->id ? 'selected' : ''}}>{{ $karyawan->nama }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="bulan_gaji" class="form-label">Gaji Bulan*</label>
                        <input type="date" class="form-control" id="bulan_gaji" name="bulan_gaji" value="{{ $row->bulan_gaji }}" placeholder="Inputkan Gaji Bulan..." required>
                    </div>

                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="{{ url('gaji') }}" class="btn btn-warning" >Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
