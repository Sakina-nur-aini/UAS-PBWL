<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <p class="mb-4"><?php echo e(__('Halo,')); ?> <strong><?php echo e(Auth::user()->name); ?></strong>! <?php echo e(__('Selamat datang di Sistem Informasi penjadwalan Sidang.')); ?></p>
                    
                    <div class="alert alert-info" role="alert">
                        <?php echo e(__('Anda telah berhasil masuk ke sistem. Sekarang Anda dapat menjadwalkan dan mengelola sidang dengan mudah.')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl\UAS\pbwl-sidang\resources\views/home.blade.php ENDPATH**/ ?>