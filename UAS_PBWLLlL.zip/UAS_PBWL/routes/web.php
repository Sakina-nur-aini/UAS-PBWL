<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/jabatan', [App\Http\Controllers\JabatanController::class, 'index']);
Route::get('/jabatan/create', [App\Http\Controllers\JabatanController::class, 'create']);
Route::post('/jabatan', [App\Http\Controllers\JabatanController::class, 'store']);
Route::get('/jabatan/edit/{id}', [App\Http\Controllers\JabatanController::class, 'edit']);
Route::patch('/jabatan/{id}', [App\Http\Controllers\JabatanController::class, 'update']);
Route::delete('/jabatan/{id}', [App\Http\Controllers\JabatanController::class, 'destroy']);

Route::get('/karyawan', [App\Http\Controllers\KaryawanController::class, 'index']);
Route::get('/karyawan/create', [App\Http\Controllers\KaryawanController::class, 'create']);
Route::post('/karyawan', [App\Http\Controllers\KaryawanController::class, 'store']);
Route::get('/karyawan/edit/{id}', [App\Http\Controllers\KaryawanController::class, 'edit']);
Route::patch('/karyawan/{id}', [App\Http\Controllers\KaryawanController::class, 'update']);
Route::delete('/karyawan/{id}', [App\Http\Controllers\KaryawanController::class, 'destroy']);

Route::get('/gaji', [App\Http\Controllers\GajiController::class, 'index']);
Route::get('/gaji/create', [App\Http\Controllers\GajiController::class, 'create']);
Route::post('/gaji', [App\Http\Controllers\GajiController::class, 'store']);
Route::get('/gaji/edit/{id}', [App\Http\Controllers\GajiController::class, 'edit']);
Route::patch('/gaji/{id}', [App\Http\Controllers\GajiController::class, 'update']);
Route::delete('/gaji/{id}', [App\Http\Controllers\GajiController::class, 'destroy']);