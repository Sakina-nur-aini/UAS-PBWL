<?php

namespace App\Http\Controllers;

use App\Models\Jabatan;
use App\Models\Karyawan;
use Illuminate\Http\Request;

class KaryawanController extends Controller
{
    public function index()
    {
        $rows = Karyawan::with('jabatan')->get();
        return view('karyawan.index', compact('rows'));

    }

    public function create()
    {
        $jabatans = Jabatan::select('id', 'nama_jabatan')->get();

        return view('karyawan.create', compact('jabatans'));
    }

    public function store(Request $request)
    {

        // Simpan data
        Karyawan::create([
            'nama' => $request->nama,
            'alamat' => $request->alamat,
            'telepon' => $request->telepon,
            'tgl_masuk' => $request->tgl_masuk,
            'id_jabatan' => $request->id_jabatan
        ]);

        // Set pesan alert
        $request->session()->flash('alert-success', 'Data berhasil disimpan!');

        // Arahkan pengguna ke rute yang diinginkan
        return redirect('karyawan');
    }

    public function edit(string $id)
    {
        $row = Karyawan::findOrFail($id);
        $jabatans = jabatan::select('id', 'nama_jabatan')->get();

        return view('karyawan.edit', compact('row', 'jabatans'));
    }

    public function update(Request $request, string $id)
    {
        $row = Karyawan::findOrFail($id);
        $row->update([
            'nama' => $request->nama,
            'alamat' => $request->alamat,
            'telepon' => $request->telepon,
            'tgl_masuk' => $request->tgl_masuk,
            'id_jabatan' => $request->id_jabatan
        ]);

        // Set pesan alert
        $request->session()->flash('alert-success', 'Data berhasil diupdate!');

        // Arahkan pengguna ke rute yang diinginkan
        return redirect('karyawan');
    }

    public function destroy(string $id)
    {
        $row = Karyawan::findOrFail($id);

        $row->delete();

        // Set pesan alert
        session()->flash('alert-success', 'Data berhasil dihapus!');

        // Arahkan pengguna ke rute yang diinginkan
        return redirect('karyawan');
    }
}
