<?php

namespace App\Http\Controllers;

use App\Models\Karyawan;
use App\Models\Gaji;
use Illuminate\Http\Request;

class GajiController extends Controller
{
    public function index()
    {
        $rows = Gaji::with('karyawan')->get();
        return view('gaji.index', compact('rows'));

    }

    public function create()
    {
        $karyawans = Karyawan::select('id', 'nama')->get();

        return view('gaji.create', compact('karyawans'));
    }

    public function store(Request $request)
    {

        // Simpan data
        Gaji::create([
            'id_karyawan' => $request->id_karyawan,
            'bulan_gaji' => $request->bulan_gaji
        ]);

        // Set pesan alert
        $request->session()->flash('alert-success', 'Data berhasil disimpan!');

        // Arahkan pengguna ke rute yang diinginkan
        return redirect('gaji');
    }

    public function edit(string $id)
    {
        $row = Gaji::findOrFail($id);
        $karyawans = Karyawan::select('id', 'nama')->get();

        return view('gaji.edit', compact('row', 'karyawans'));
    }

    public function update(Request $request, string $id)
    {
        $row = Gaji::findOrFail($id);
        $row->update([
            'id_karyawan' => $request->id_karyawan,
            'bulan_gaji' => $request->bulan_gaji
        ]);

        // Set pesan alert
        $request->session()->flash('alert-success', 'Data berhasil diupdate!');

        // Arahkan pengguna ke rute yang diinginkan
        return redirect('gaji');
    }

    public function destroy(string $id)
    {
        $row = Gaji::findOrFail($id);

        $row->delete();

        // Set pesan alert
        session()->flash('alert-success', 'Data berhasil dihapus!');

        // Arahkan pengguna ke rute yang diinginkan
        return redirect('gaji');
    }
}
