

<?php $__env->startSection('content'); ?>
<div class="container"> 
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Form Edit Jadwal Sidang</h5>
            <div class="col-sm-8">
                <form class="row g-3 mt-2" action="<?php echo e(url('jadwal/' . $row->id)); ?>" method="POST">
                    <input type="hidden" name="_method" value="PATCH">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="id_pengadilan" class="form-label">Pengadilan*</label>
                        <select class="form-control" name="id_pengadilan" id="id_pengadilan">
                            <option value="">-- Pilih --</option>
                            <?php $__currentLoopData = $pengadilans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengadilan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pengadilan->id); ?>" <?php echo e($row->id_pengadilan == $pengadilan->id ? 'selected' : ''); ?>><?php echo e($pengadilan->nama_pengadilan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="tgl_sidang" class="form-label">Tanggal Sidang*</label>
                        <input type="date" class="form-control" id="tgl_sidang" name="tgl_sidang" value="<?php echo e($row->tgl_sidang); ?>" placeholder="Inputkan Tanggal Sidang..." required>
                    </div>

                    <div class="mb-3">
                        <label for="waktu_sidang" class="form-label">Waktu Sidang*</label>
                        <input type="time" class="form-control" id="waktu_sidang" name="waktu_sidang" value="<?php echo e($row->waktu_sidang); ?>" placeholder="Inputkan Waktu Sidang..." required>
                    </div>

                    <div class="mb-3">
                    <label for="jenis_perkara" class="form-label">Jenis Perkara*</label>
                    <select class="form-control" name="jenis_perkara" id="jenis_perkara">
                        <option value="">-- Pilih --</option>
                        <option value="perdata" <?php echo e($row->jenis_perkara == 'perdata' ? 'selected' : ''); ?>>Perdata</option>
                        <option value="pidana" <?php echo e($row->jenis_perkara == 'pidana' ? 'selected' : ''); ?>>Pidana</option>
                        <option value="tata usaha negara" <?php echo e($row->jenis_perkara == 'tata usaha negara' ? 'selected' : ''); ?>>Tata Usaha Negara</option>
                        <option value="hubungan industrial" <?php echo e($row->jenis_perkara == 'hubungan industrial' ? 'selected' : ''); ?>>Hubungan Industrial</option>
                            <option value="pailit dan kepailitan" <?php echo e($row->jenis_perkara == 'pailit dan kepailitan' ? 'selected' : ''); ?>>Pailit dan Kepailitan</option>
                            <option value="tanah dan agraria" <?php echo e($row->jenis_perkara == 'tanah dan agraria' ? 'selected' : ''); ?>>Tanah dan Agraria</option>
                            <option value="waris" <?php echo e($row->jenis_perkara == 'waris' ? 'selected' : ''); ?>>Waris</option>
                            <option value="perlindungan konsumen" <?php echo e($row->jenis_perkara == 'perlindungan konsumen' ? 'selected' : ''); ?>>Perlindungan Konsumen</option>
                    </select>
                </div>


                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?php echo e(url('jadwal')); ?>" class="btn btn-warning" >Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl\UAS\pbwl-sidang\resources\views/jadwal/edit.blade.php ENDPATH**/ ?>