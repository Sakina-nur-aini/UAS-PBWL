

<?php $__env->startSection('content'); ?>
<div class="container"> 
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Form Penggajian</h5>
            <div class="col-sm-8">
                <form class="row g-3 mt-2" action="<?php echo e(url('gaji')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="id_karyawan" class="form-label">Karyawan*</label>
                        <select class="form-control" name="id_karyawan" id="id_karyawan">
                            <option value="">-- Pilih --</option>
                            <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karyawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($karyawan->id); ?>"><?php echo e($karyawan->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="bulan_gaji" class="form-label">Gaji Bulan*</label>
                        <input type="date" class="form-control" id="bulan_gaji" name="bulan_gaji" placeholder="Inputkan Gaji Bulan..." required>
                    </div>

                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(url('gaji')); ?>" class="btn btn-warning" >Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl\UAS\pbwl-gaji\resources\views/gaji/create.blade.php ENDPATH**/ ?>