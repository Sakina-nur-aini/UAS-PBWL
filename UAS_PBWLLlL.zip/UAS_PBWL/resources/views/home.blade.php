@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-danger text-white">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <p class="mb-4">{{ __('Halo,') }} <strong>{{ Auth::user()->name }}</strong>! {{ __('Selamat datang di Sistem Penggajian Karyawan!') }}</p>
                    
                    <div class="alert alert-info" role="alert">
                        {{ __('Kami senang Anda telah bergabung. Mari kelola gaji karyawan dengan lebih efisien dan transparan. Semoga pengalaman Anda di sini menyenangkan!') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
