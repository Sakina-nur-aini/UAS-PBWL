    
    
    <?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="card">
        <div class="card-body">
        <h5>Form Edit Golongan</h5>
        <div class="col-sm-6">
            <form class="row g-3 mt-2" action="<?php echo e(url('golongan/' . $row->id)); ?>" method="POST">
            <input type="hidden" name="_method" value="PATCH">
                <?php echo csrf_field(); ?>
            <div class="form-group"> 
                <label for="gol_kode" class="form-label">Kode*</label>
                <input type="text" class="form-control" name="gol_kode" id="gol_kode" value="<?php echo e($row->gol_kode); ?>" placeholder="Kode">
            </div>

            <div class="form-group">
                <label for="gol_nama" class="form-label">Nama*</label>
                <input type="text" class="form-control" name="gol_nama" id="gol_nama" value="<?php echo e($row->gol_nama); ?>" placeholder="Nama">
            </div>
            <br>
            <div class="form-group">
                <input type="submit" value="Update" class="btn btn-primary">
            </div>
            </form>
        </div>
        </div>
    </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl\pertemuan7\pbwl-quiz\resources\views/golongan/edit.blade.php ENDPATH**/ ?>