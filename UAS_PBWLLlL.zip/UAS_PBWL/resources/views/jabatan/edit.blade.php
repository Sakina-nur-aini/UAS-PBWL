@extends('layouts.app')

@section('content')
<div class="container">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Form Edit Jabatan</h5>
            <div class="col-sm-8">
                <form class="row g-3 mt-2" action="{{ url('jabatan/' . $row->id) }}" method="POST">
                    <input type="hidden" name="_method" value="PATCH">
                    @csrf

                    <div class="mb-3">
                        <label for="nama_jabatan" class="form-label">Jabatan*</label>
                        <input type="text" class="form-control" id="nama_jabatan" name="nama_jabatan" value="{{ $row->nama_jabatan }}" placeholder="Inputkan Jabatan..." required>
                    </div>

                    <div class="mb-3">
                        <label for="besaran_gaji" class="form-label">Besaran Gaji*</label>
                        <input type="number" class="form-control" id="besaran_gaji" name="besaran_gaji" value="{{ $row->besaran_gaji }}" placeholder="Inputkan Besaran Gaji..." required>
                    </div>

                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="{{ url('jabatan') }}" class="btn btn-warning" >Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
