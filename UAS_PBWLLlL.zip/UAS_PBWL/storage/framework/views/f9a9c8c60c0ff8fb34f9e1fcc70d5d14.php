    
    
    <?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="card">
        <div class="card-body">
            
        <!-- Konten Anda -->
        <script>
            <?php if(session('alert-success')): ?>
                alert('<?php echo e(session('alert-success')); ?>');
            <?php endif; ?>
        </script>


        <strong><h3>Data Peserta</h3></strong>
        <a href="<?php echo e(url('peserta/create')); ?>" class="btn btn-primary mb-3 float-end"><i class="bi bi-plus"></i> Tambah Baru</a>

        <table id="dataTable" class="table table-hover table-striped table-bordered"><table class="table table-hover table-striped table-bordered">
            <thead>
            <tr>
                <th scope="col" class="text-center">No</th>
                <th scope="col">Nama Peserta</th>
                <th scope="col">Tanggal Sidang</th>
                <th scope="col">Peran Peserta</th>
                <th scope="col" class="text-center">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1; ?>
            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th class="text-center"><?php echo e($no++); ?></th>
                <td><?php echo e($peserta->nama_peserta); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($peserta->jadwal->tgl_sidang)->format('d/m/Y')); ?></td>
                <td><?php echo e($peserta->peran_peserta); ?></td>
                <td class="text-center">
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(url('peserta/edit/' . $peserta->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(url('peserta/' . $peserta->id)); ?>" method="post">
                            <input type="hidden" name="_method" value="DELETE">
                            <?php echo csrf_field(); ?>
                            <input type="submit" value="Delete" class="btn btn-danger" onclick="return confirm('Ingin Menghapus Data Ini ?');">
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl\UAS\pbwl-sidang\resources\views/peserta/index.blade.php ENDPATH**/ ?>