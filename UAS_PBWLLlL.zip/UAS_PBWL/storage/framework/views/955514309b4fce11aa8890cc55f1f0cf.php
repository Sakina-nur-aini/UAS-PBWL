    
    
    <?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="card">
        <div class="card-body">
        <h5>Data Golongan</h5>
        <a href="<?php echo e(url('golongan/create')); ?>" class="btn btn-primary mb-3 float-end">Tambah Baru</a>

        <table class="table table-hover table-striped table-bordered">
            <thead>
            <tr>
                <th scope="col" class="text-center">No</th>
                <th scope="col">Kode</th>
                <th scope="col">Nama</th>
                <th scope="col" class="text-center">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1; ?>
            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $golongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th class="text-center"><?php echo e($no++); ?></th>
                <td><?php echo e($golongan->gol_kode); ?></td>
                <td><?php echo e($golongan->gol_nama); ?></td>
                <td class="text-center">
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(url('golongan/edit/' . $golongan->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(url('golongan/' . $golongan->id)); ?>" method="post">
                            <input type="hidden" name="_method" value="DELETE">
                            <?php echo csrf_field(); ?>
                            <input type="submit" value="Delete" class="btn btn-danger">
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl\pertemuan7\pbwl-quiz\resources\views/golongan/index.blade.php ENDPATH**/ ?>