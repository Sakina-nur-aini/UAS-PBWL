<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Model;

class Karyawan extends Model
{
    use HasFactory;

    protected $table = 'tb_karyawan'; 

    protected $fillable = [
        'nama', 'alamat', 'telepon', 'tgl_masuk', 'id_jabatan'
    ];

    public function jabatan(): HasOne
    {
        return $this->hasOne(Jabatan::class, 'id', 'id_jabatan');
    }

}
