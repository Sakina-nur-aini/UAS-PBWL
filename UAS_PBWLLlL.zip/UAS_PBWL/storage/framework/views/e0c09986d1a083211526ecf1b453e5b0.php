

<?php $__env->startSection('content'); ?>
<div class="container"> 
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Form Edit Jabatan</h5>
            <div class="col-sm-8">
                <form class="row g-3 mt-2" action="<?php echo e(url('karyawan/' . $row->id)); ?>" method="POST">
                    <input type="hidden" name="_method" value="PATCH">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama*</label>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($row->nama); ?>" placeholder="Inputkan Nama..." required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat*</label>
                        <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo e($row->alamat); ?>" placeholder="Inputkan Alamat..." required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="telepon" class="form-label">Nomor Telepon*</label>
                        <input type="text" class="form-control" id="telepon" name="telepon" value="<?php echo e($row->telepon); ?>" placeholder="Inputkan Nomor Telepon..." required>
                    </div>

                    <div class="mb-3">
                        <label for="tgl_masuk" class="form-label">Tanggal Masuk*</label>
                        <input type="date" class="form-control" id="tgl_masuk" name="tgl_masuk" value="<?php echo e($row->tgl_masuk); ?>" placeholder="Inputkan Tanggal Masuk..." required>
                    </div>
                    <div class="mb-3">
                        <label for="id_jabatan" class="form-label">Jabatan*</label>
                        <select class="form-control" name="id_jabatan" id="id_jabatan">
                            <option value="">-- Pilih --</option>
                            <?php $__currentLoopData = $jabatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($jabatan->id); ?>" <?php echo e($row->id_jabatan == $jabatan->id ? 'selected' : ''); ?>><?php echo e($jabatan->nama_jabatan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?php echo e(url('karyawan')); ?>" class="btn btn-warning" >Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl\UAS\pbwl-gaji\resources\views/karyawan/edit.blade.php ENDPATH**/ ?>