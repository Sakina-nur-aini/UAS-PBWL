<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Model;

class Gaji extends Model
{
    use HasFactory;

    protected $table = 'tb_gaji'; 

    protected $fillable = [
        'id_karyawan', 'bulan_gaji'
    ];

    public function karyawan(): HasOne
    {
        return $this->hasOne(Karyawan::class, 'id', 'id_karyawan');
    }

}
