

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Form Edit Jabatan</h5>
            <div class="col-sm-8">
                <form class="row g-3 mt-2" action="<?php echo e(url('jabatan/' . $row->id)); ?>" method="POST">
                    <input type="hidden" name="_method" value="PATCH">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="nama_jabatan" class="form-label">Jabatan*</label>
                        <input type="text" class="form-control" id="nama_jabatan" name="nama_jabatan" value="<?php echo e($row->nama_jabatan); ?>" placeholder="Inputkan Jabatan..." required>
                    </div>

                    <div class="mb-3">
                        <label for="besaran_gaji" class="form-label">Besaran Gaji*</label>
                        <input type="number" class="form-control" id="besaran_gaji" name="besaran_gaji" value="<?php echo e($row->besaran_gaji); ?>" placeholder="Inputkan Besaran Gaji..." required>
                    </div>

                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?php echo e(url('jabatan')); ?>" class="btn btn-warning" >Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl\UAS\pbwl-gaji\resources\views/jabatan/edit.blade.php ENDPATH**/ ?>