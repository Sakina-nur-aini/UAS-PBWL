    
    
    <?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="card">
        <div class="card-body">
        <h5>Form Edit User</h5>
        <div class="col-sm-6">
            <form class="row g-3 mt-2" action="<?php echo e(url('users/' . $row->id)); ?>" method="POST">
            <input type="hidden" name="_method" value="PATCH">
                <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="name" class="form-label">Nama*</label>
                <input type="text" class="form-control" name="name" id="name" value="<?php echo e($row->name); ?>" placeholder="Nama">
            </div>

            <div class="form-group">
                <label for="email" class="form-label">Email*</label>
                <input type="text" class="form-control" name="email" id="email" value="<?php echo e($row->email); ?>" placeholder="Email">
            </div>
            <br>
            <div class="form-group">
                <input type="submit" value="Update" class="btn btn-primary">
            </div>
            </form>
        </div>
        </div>
    </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl\pertemuan7\pbwl-quiz\resources\views/auth/user/edit.blade.php ENDPATH**/ ?>